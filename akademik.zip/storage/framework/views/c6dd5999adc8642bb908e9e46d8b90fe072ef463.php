<table class="table table-bordered">
   <tr>
       <th>NIS</th>
       <td><?php echo e($siswa->nis); ?></td>
   </tr>
   <tr>
       <th>Nama</th>
       <td><?php echo e($siswa->nama); ?></td>
   </tr>
   <tr>
       <th>Nama Panggilan</th>
       <td><?php echo e($siswa->nama_panggilan); ?></td>
   </tr>
   <tr>
       <th>Jenis Kelamin</th>
       <td><?php echo e($siswa->jenis_kelamin==1?'Laki-Laki':'Perempuan'); ?></td>
   </tr>
   <tr>
       <th>Tempat, Tanggal Lahir</th>
       <td><?php echo e($siswa->tempat_lahir); ?>, <?php echo e($siswa->tanggal_lahir); ?></td>
   </tr>
   <tr>
      <th>Tipe, Kelas</th>
      <td><?php echo e($siswa->tipe==1?'Fullday':'Boarding'); ?>, <?php echo e($siswa->kelas); ?> <?php echo e($siswa->jurusan); ?></td>
  </tr>
   <tr>
       <th>Alamat</th>
       <td><?php echo e($siswa->alamat); ?></td>
   </tr>
   <tr>
       <th>Anak Ke -</th>
       <td><?php echo e($siswa->anak_ke); ?></td>
   </tr>
   <tr>
       <th>Jumlah Saudara</th>
       <td><?php echo e($siswa->jml_saudara); ?></td>
   </tr>
   <tr>
       <th>Berat, Tinngi, Gol.Darag</th>
   <td><?php echo e($siswa->berat); ?> Kg, <?php echo e($siswa->tinggi); ?> cm, <?php echo e($siswa->gol_darah); ?></td>
   </tr>
   
</table><?php /**PATH C:\xampp\htdocs\akademik\resources\views/siswa/show.blade.php ENDPATH**/ ?>