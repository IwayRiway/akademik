<?php
    $side = Request::segment(1);
?>
<div class="main-sidebar sidebar-style-2">
   <aside id="sidebar-wrapper">
     <div class="sidebar-brand">
       <a href="index.html">SI-Akademik</a>
     </div>
     <div class="sidebar-brand sidebar-brand-sm">
       <a href="index.html">SIA</a>
     </div>
     <ul class="sidebar-menu">
       <li class="menu-header">Navigation</li>
       <li class="<?php echo e($side=='dashboard'?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>"><i class="fas fa-columns"></i><span>Dashboard</span></a></li>

       <li class="<?php echo e($side=='siswa'?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('siswa.index')); ?>"><i class="fas fa-graduation-cap"></i><span>Data Siswa</span></a></li> 

       <li class="<?php echo e($side=='dashboard'?'mapel':''); ?>"><a class="nav-link" href="<?php echo e(route('mapel.index')); ?>"><i class="fas fa-book"></i><span>Data Mata Pelajaran</span></a></li>

       <li class="<?php echo e($side=='guru'?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('guru.index')); ?>"><i class="fas fa-user-graduate"></i><span>Data Guru</span></a></li> 

       <li class="<?php echo e($side=='jam-pelajaran'?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('jam-pelajaran.index')); ?>"><i class="fas fa-clock"></i><span>Master Data Jam</span></a></li> 

       <li <?php echo e($side=='jadwal'?'active':''); ?>><a class="nav-link" href="<?php echo e(route('jadwal.index')); ?>"><i class="fas fa-school"></i><span>Master Kelas</span></a></li> 

       <li <?php echo e($side=='jadwal-pelajaran'?'active':''); ?>><a class="nav-link" href="<?php echo e(route('jadwal-pelajaran.index')); ?>"><i class="fas fa-calendar-alt"></i><span>Jadwal Pelajaran</span></a></li> 

       <li <?php echo e($side=='jadwal-siswa'?'active':''); ?>><a class="nav-link" href="<?php echo e(route('jadwal-siswa.index')); ?>"><i class="fas fa-users"></i><span>Master Kelas Siswa</span></a></li> 

       <li <?php echo e($side=='report'?'active':''); ?>><a class="nav-link" href="<?php echo e(route('report.index')); ?>"><i class="fas fa-clipboard"></i><span>Report</span></a></li>
       
       <li class="dropdown <?php echo e($side=='role-access'?'active':''); ?> <?php echo e($side=='role-access'?'active':''); ?> <?php echo e($side=='user'?'active':''); ?>" >
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-users-cog"></i><span>Manajemen Menu</span></a>
         <ul class="dropdown-menu">
           <li class="<?php echo e($side=='role-access'?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('role-access.index')); ?>">Role Access</a></li>
           <li class="<?php echo e($side=='access'?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('access.index')); ?>">Menu Role Access</a></li>
           <li class="<?php echo e($side=='user'?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('user.index')); ?>">User Manajemen</a></li>
         </ul>
       </li>
   </aside>
 </div><?php /**PATH C:\xampp\htdocs\akademik\resources\views/templates/includes/sidebar.blade.php ENDPATH**/ ?>