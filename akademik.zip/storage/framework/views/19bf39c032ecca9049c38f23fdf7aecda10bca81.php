<div class="row">
   <div class="col-sm-3">
      <?php if($guru->poto==null): ?>
         <img src="<?php echo e(asset('assets/img/avatar/avatar-3.png')); ?>" alt="" width="100" class="mt-5 ml-2">
      <?php else: ?>
      <img src="<?php echo e(asset("storage/$guru->poto")); ?>" alt="" width="100" class="mt-5 ml-2">
      <?php endif; ?>
   </div>

   <div class="col-sm-9">
      <table class="table table-bordered">
         <tr>
            <th>NIP</th>
            <td><?php echo e($guru->nip); ?></td>
         </tr>
         <tr>
            <th>Nama Lengkap</th>
            <td><?php echo e($guru->nama); ?></td>
         </tr>
         <tr>
            <th>Tempat, Tanggal Lahir</th>
            <td><?php echo e($guru->tempat); ?>, <?php echo e(date('d F Y', strtotime($guru->tanggal_lahir))); ?></td>
         </tr>
         <tr>
            <th>Jenis Kelamin</th>
            <td><?php echo e($guru->jenis_kelamin==1?'Laki-Laki':'Perempuan'); ?></td>
         </tr>
      </table>
   </div>
</div>
<div class="row">
   <div class="col-sm-12">
      <table class="table table-bordered">
         <th>Alamat Lengkap</th>
         <td><?php echo e($guru->alamat); ?></td>
      </table>
   </div>
</div><?php /**PATH C:\xampp\htdocs\akademik\resources\views/guru/show.blade.php ENDPATH**/ ?>