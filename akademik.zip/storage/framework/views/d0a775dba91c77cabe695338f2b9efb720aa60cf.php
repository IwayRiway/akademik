
<?php $__env->startSection('content'); ?>

<section class="section">
   <div class="section-header">
     <h1><?php echo e($judul); ?></h1>
   </div>

   <div class="section-body">

    <div class="row">

      <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <div class="card card-statistic-1">
          <div class="card-icon bg-primary">
            <i class="fas fa-user-graduate"></i>
          </div>
          <div class="card-wrap">
            <div class="card-header">
              <h4>Total Guru</h4>
            </div>
            <div class="card-body">
              <?php echo e($guru); ?>

            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <div class="card card-statistic-1">
          <div class="card-icon bg-danger">
            <i class="fas fa-graduation-cap"></i>
          </div>
          <div class="card-wrap">
            <div class="card-header">
              <h4>Total Siswa</h4>
            </div>
            <div class="card-body">
              <?php echo e($siswa); ?>

            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <div class="card card-statistic-1">
          <div class="card-icon bg-warning">
            <i class="fas fa-school"></i>
          </div>
          <div class="card-wrap">
            <div class="card-header">
              <h4>Total Kelas</h4>
            </div>
            <div class="card-body">
              <?php echo e(count($kelas)); ?>

            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <div class="card card-statistic-1">
          <div class="card-icon bg-success">
            <i class="fas fa-book"></i>
          </div>
          <div class="card-wrap">
            <div class="card-header">
              <h4>Total Mata Pelajaran</h4>
            </div>
            <div class="card-body">
              <?php echo e($mapelnya); ?>

            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="row">
      <div class="col-12 col-sm-5 col-lg-5">
        <div class="card">
          <div class="card-header">
            <h4>Jadwal Hari Ini : <?php echo e(date('l')); ?>, <?php echo e(date('d F Y')); ?></h4>
          </div>
          <div class="card-body">
            <ul class="nav nav-pills" id="myTab3" role="tablist">
              <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                  <a class="nav-link <?php echo e($loop->iteration==1?'active':''); ?>" id="home-tab<?php echo e($db->id); ?>" data-toggle="tab" href="#home<?php echo e($db->id); ?>" role="tab" aria-controls="home" aria-selected="true"><?php echo e($db->kelas); ?>-<?php echo e($db->jurusan); ?>-<?php echo e($db->postfix); ?></a>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabContent2">
              <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->iteration==1?'show active':''); ?>" id="home<?php echo e($db->id); ?>" role="tabpanel" aria-labelledby="home-tab<?php echo e($db->id); ?>">
                  <table class="table table-hovered table-striped datatable">
                      <thead>
                        <tr>
                          <th>Jam</th>
                          <th>Mata Pelajaran</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if(array_key_exists($db->id, $skrg)): ?>
                          <?php for($i = 0; $i < count($skrg[$db->id]); $i++): ?>
                            <tr>
                              <td><?php echo e($skrg[$db->id][$i]['jam']); ?></td>
                              <td><?php echo e($skrg[$db->id][$i]['mapel']); ?></td>
                            </tr>
                          <?php endfor; ?>
                        <?php endif; ?>
                      </tbody>
                  </table>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-7 col-lg-7">
        <div class="card">
          <div class="card-header">
            <h4>Jadwal Besok : <?php echo e(date('l', strtotime('+1 days', strtotime(date('Y-m-d'))))); ?>, <?php echo e(date('d F Y', strtotime('+1 days', strtotime(date('Y-m-d'))))); ?></h4>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12 col-sm-12 col-md-3">
                <ul class="nav nav-pills flex-column" id="myTab4" role="tablist">
                  <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                      <a class="nav-link <?php echo e($loop->iteration==1?'active':''); ?>" id="home-tab-besok<?php echo e($db->id); ?>" data-toggle="tab" href="#home-besok<?php echo e($db->id); ?>" role="tab" aria-controls="home" aria-selected="true"><?php echo e($db->kelas); ?>-<?php echo e($db->jurusan); ?>-<?php echo e($db->postfix); ?></a>
                    </li>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <div class="col-12 col-sm-12 col-md-9">
                <div class="tab-content no-padding" id="myTab2Content">
                  <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="tab-pane fade <?php echo e($loop->iteration==1?'show active':''); ?>" id="home-besok<?php echo e($db->id); ?>" role="tabpanel" aria-labelledby="home-tab-besok<?php echo e($db->id); ?>">
                    <table class="table table-hovered table-striped datatable">
                        <thead>
                          <tr>
                            <th>Jam</th>
                            <th>Mata Pelajaran</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if(array_key_exists($db->id, $bsk)): ?>
                          <?php for($i = 0; $i < count($bsk[$db->id]); $i++): ?>
                            <tr>
                              <td><?php echo e($bsk[$db->id][$i]['jam']); ?></td>
                              <td><?php echo e($bsk[$db->id][$i]['mapel']); ?></td>
                            </tr>
                          <?php endfor; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

   </div>
 </section>
   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    <script>
      $(document).ready(function(){
        $('.datatable').DataTable({
          "dom":"ftip",
          "ordering": false,
          "lengthChange": false,
          "paging":   false,
        });
      });
    </script>
<?php $__env->stopPush(); ?>
 
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\akademik\resources\views/dashboard/index.blade.php ENDPATH**/ ?>