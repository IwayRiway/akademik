
<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/modules/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
   <div class="section-header">
     <h1><?php echo e($judul); ?></h1>
   </div>

   <div class="section-body">

      <div class="row">
        <div class="col-sm-12">
            <div class="card card-primary">

                <div class="card-body " id="jadwal-guru">
                  <form action="<?php echo e(route('jadwal-pelajaran.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <table class="table table-bordered table-hover">
                        <thead>
                          <tr>
                            <th>No.</th>
                            <th>Jam Pelajaran</th>
                            <th>Mata Pelajaran</th>
                            <th>Guru</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $jam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($db->jam_awal); ?> - <?php echo e($db->jam_akhir); ?></td>
                                <td>
                                  <select class="form-control mapel_id" name="mapel_id_<?php echo e($db->id); ?>" id="mapel_id_<?php echo e($db->id); ?>" style="width: 100%">
                                    <option></option>
                                    <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($db1->id); ?>"><?php echo e($db1->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <option value="00">Upacara</option>
                                    <option value="0">Istirahat</option>
                                  </select>
                                </td>
                                <td>
                                  <select class="form-control guru_id" name="guru_id_<?php echo e($db->id); ?>" id="guru_id_<?php echo e($db->id); ?>" style="width: 100%">
                                    <option></option>
                                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($db2->id); ?>"><?php echo e($db2->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </td>
                              </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <hr style="border: 1px solid black">
                    <div class="form-group row">
                      <label for="kelas" class="col-sm-3 col-form-label text-right">Pilih Kelas <code>*</code> : </label>
                      <div class="col-sm-6">
                         
                         <select name="kelas" id="kelas" class="form-control kelas">
                           <option></option>
                           <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($db->id); ?>"><?php echo e($db->kelas); ?>-<?php echo e($db->jurusan); ?>-<?php echo e($db->postfix); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                      </div>
                   </div>

                    <div class="form-group row">
                      <label for="hari" class="col-sm-3 col-form-label text-right">Pilih Hari <code>*</code> : </label>
                      <div class="col-sm-6">
                         <select name="hari" id="hari" class="form-control select2" onchange="hari(this.value)">
                           <option></option>
                           <option value="1">Senin</option>
                           <option value="2">Selasa</option>
                           <option value="3">Rabu</option>
                           <option value="4">Kamis</option>
                           <option value="5">Jumat</option>
                         </select>
                      </div>
                   </div>

                   <div class="row">
                     <div class="col-sm-12 text-center">
                      <button class="btn btn-primary hilang" type="submit" id="submit">Submit</button>
                      <a class="btn btn-secondary" href="<?php echo e(route('jadwal-pelajaran.index')); ?>">Cancel</a>
                     </div>
                   </div>
                  </form>
                </div>

            </div>
        </div>
      </div>

   </div>
 </section>
   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script src="<?php echo e(asset('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
<script>
  // function kelas(val) {
    // var hari = $('#hari').val();
    // if(val!="" && hari!=""){
    //   cekJadwal(val,hari);
    // } else {
    //   $("#submit").addClass('hilang');
    // }
  // }

  // function hari(val) {
  //   var kelas = $('#kelas').val();
  //   if(val!="" && kelas!=""){
  //     cekJadwal(kelas,val);
  //   } else {
  //     $("#submit").addClass('hilang');
  //     myalert("Anda Harus Memilih Hari dan Kelas");
  //   }
  // }

  $(document).ready(function(){
    $(".mapel_id").select2({
        placeholder: "Pilih Mata Pelajaran",
        allowClear: true
    });

    $(".guru_id").select2({
        placeholder: "Pilih Guru Pengajar",
        allowClear: true
    });

    $("#hari").select2({
        placeholder: "Pilih Hari Penjadwalan",
        allowClear: true
    });

    $("#kelas").select2({
        placeholder: "Pilih Kelas",
        allowClear: true
    });

    $('#kelas').on('change', function() {
        var val = this.value;
        var hari = $('#hari').val();
        if(val!="" && hari!=""){
          cekJadwal(val,hari);
        } else {
          $("#submit").addClass('hilang');
        }
    });

    $('#hari').on('change', function() {
        var val = this.value;
        var kelas = $('#kelas').val();
        if(val!="" && kelas!=""){
          cekJadwal(kelas,val);
        } else {
          $("#submit").addClass('hilang');
        }
    });

    function myalert(params) {
      Swal.fire({
        position: 'center',
        icon: 'warning',
        title: 'Maaf Proses Gagal',
        text: params,
        showConfirmButton: true
      })
    }

    function cekJadwal(kelas,hari) {
      $.ajax({
          url : `<?php echo e(route('jadwal-pelajaran.jadwal')); ?>`,
          type : "POST",
          dataType : "json",
          data    : {_token:"<?php echo e(csrf_token()); ?>", jadwal_id:kelas, hari:hari},
          success : function(data) {
            if(data==0){
              $("#submit").addClass('hilang');
              myalert("Jadwal sudah tersedia");
            } else {
              $("#submit").removeClass('hilang');
            }
          }
      });
    }

  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\akademik\resources\views/jadwal-pelajaran/create.blade.php ENDPATH**/ ?>