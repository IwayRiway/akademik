<form action="<?php echo e(route('report.update', $report->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<div class="row">
  <div class="col-sm-12">

  <div class="form-group row">
    <label for="mapel_id" class="col-sm-5 col-form-label text-left">Mata Pelajaran <code>*</code> : </label>
    <div class="col-sm-7">
        <input type="text" name="mapel_id" id="mapel_id" value="<?php echo e($report->mapel->nama); ?>" disabled class="form-control">
    </div>
  </div>

  <div class="form-group row">
    <label for="guru_id" class="col-sm-5 col-form-label text-left">Pilih Guru Pengajar <code>*</code> : </label>
    <div class="col-sm-7">
        <input type="text" name="nilai" id="nilai" value="<?php echo e($report->nilai); ?>" max="100" min="0" required class="form-control">
    </div>
  </div>
  <hr>
  <div class="row">
    <div class="col-sm-12 text-right">
      <button class="btn btn-primary" type="submit">Save</button>
    </div>
  </div>

  </div>
</div>
</form><?php /**PATH C:\xampp\htdocs\akademik\resources\views/report/show.blade.php ENDPATH**/ ?>