
<?php $__env->startSection('content'); ?>

<section class="section">
   <div class="section-header">
     <h1>Blank Page</h1>
   </div>

   <div class="section-body">
   </div>
 </section>
   
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\akademik\resources\views/templates/blank.blade.php ENDPATH**/ ?>