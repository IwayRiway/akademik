
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>SI &mdash; Akademik</title>

  <?php echo $__env->make('templates/includes/style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldPushContent('style'); ?>
  <style>
    .hilang{
      display: none !important;
    }
  </style>
<!-- /END GA --></head>

<body>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">

      <?php echo $__env->make('templates/includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('templates/includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      <div class="info" data-flashdata="<?php echo e(session('info')); ?>"></div>
      <div class="gagal" data-flashdata="<?php echo e(session('gagal')); ?>"></div>
      <div class="sukses" data-flashdata="<?php echo e(session('sukses')); ?>"></div>
      <div class="warning" data-flashdata="<?php echo e(session('warning')); ?>"></div>
      
      <!-- Main Content -->
      <div class="main-content">
        <?php echo $__env->yieldContent('content'); ?>
      </div>

      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2020 <div class="bullet"></div> Develop By <a href="#">Riway Restu Islami Yudha</a>
        </div>
        <div class="footer-right">
          
        </div>
      </footer>
    </div>
  </div>

  <?php echo $__env->yieldPushContent('before-script'); ?>
  <?php echo $__env->make('templates/includes/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldPushContent('after-script'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\akademik\resources\views/templates/main.blade.php ENDPATH**/ ?>