
<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap-timepicker/css/bootstrap-timepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
   <div class="section-header">
     <h1><?php echo e($judul); ?></h1>
   </div>

   <div class="section-body">

      <div class="row">
         <div class="col-sm-12">
             <div class="card card-primary">
               <form action="<?php echo e(route('jam-pelajaran.update', $jam->id)); ?>" method="post">
                 <div class="card-body">

                     <?php echo csrf_field(); ?>
                     <?php echo method_field('PUT'); ?>
                     <div class="form-group row">
                        <label for="" class="col-sm-3 col-form-label text-right">Jam Pelajaran <code>*</code> : </label>
                        <div class="col-sm-6">
                           <div class="row">
                              <div class="col-sm-6">
                                 <input type="text" class="form-control <?php $__errorArgs = ['jam_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jam_awal" placeholder="--:--" name="jam_awal" value="<?php echo e($jam->jam_awal); ?>" >
                                  <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('nama')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              <div class="col-sm-6">
                                 <input type="text" class="form-control <?php $__errorArgs = ['jam_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jam_akhir" placeholder="--:--" name="jam_akhir" value="<?php echo e($jam->jam_akhir); ?>" >
                                 <?php $__errorArgs = ['jam_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('jam_akhir')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                           </div>
                        </div>
                     </div>

                 </div>

                 <div class="card-footer text-center">
                     <button class="btn btn-primary mr-1" type="submit">Save</button>
                     <a href="<?php echo e(route('jam-pelajaran.index')); ?>" class="btn btn-secondary">Cancel</a>
                  </div>
               </form>

             </div>
         </div>
      </div>

   </div>
 </section>
   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
  <script src="<?php echo e(asset('assets/modules/bootstrap-timepicker/js/bootstrap-timepicker.min.js')); ?>"></script>

<script>
   $(document).ready(function(){
      $('#jam_awal').timepicker({
         showInputs: false,
         showMeridian: false,
         icons: {
            up: "fa fa-chevron-circle-up",
            down: "fa fa-chevron-circle-down",
         }
      });
      $('#jam_akhir').timepicker({
         showInputs: false,
         showMeridian: false,
         icons: {
            up: "fa fa-chevron-circle-up",
            down: "fa fa-chevron-circle-down",
         }
      });
   });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\akademik\resources\views/jam-pelajaran/edit.blade.php ENDPATH**/ ?>