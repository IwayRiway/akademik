

<?php $__env->startPush('style'); ?>
    <style>
       .datepicker {
            font-size: 0.875em !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
   <div class="section-header">
     <h1><?php echo e($judul); ?></h1>
   </div>

   <div class="section-body">

      <div class="row">
         <div class="col-sm-12">
             <div class="card card-primary">
               <form action="<?php echo e(route('guru.update', $guru->id)); ?>" method="post" enctype="multipart/form-data">
                 <div class="card-body">

                     <?php echo csrf_field(); ?>
                     <?php echo method_field('PUT'); ?>
                     <div class="form-group row">
                        <label for="nip" class="col-sm-3 col-form-label text-right">Nip <code>*</code> : </label>
                        <div class="col-sm-6">
                           <input type="text" class="form-control <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nip" placeholder="Nomor Induk Pegawai" name="nip" value="<?php echo e($guru->nip); ?>" >
                           <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('nip')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>

                     <div class="form-group row">
                        <label for="nama" class="col-sm-3 col-form-label text-right">Nama <code>*</code> : </label>
                        <div class="col-sm-6">
                           <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" placeholder="Nama Lengkap" name="nama" value="<?php echo e($guru->nama); ?>" >
                           <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('nama')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>

                     <div class="form-group row">
                        <label for="tempat" class="col-sm-3 col-form-label text-right">Tempat Lahir<code>*</code> : </label>
                        <div class="col-sm-6">
                           <input type="text" class="form-control <?php $__errorArgs = ['tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tempat" placeholder="Tempat Lahir" name="tempat" value="<?php echo e($guru->tempat); ?>" >
                           <?php $__errorArgs = ['tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('tempat')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>

                     <div class="form-group row">
                        <label for="tanggal_lahir" class="col-sm-3 col-form-label text-right">Tanggal Lahir<code>*</code> : </label>
                        <div class="col-sm-6">
                           <input type="text" class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> tanggal_lahir" id="tanggal_lahir" placeholder="Tanggal Lahir" name="tanggal_lahir" value="<?php echo e($guru->tanggal_lahir); ?>" >
                           <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('tanggal_lahir')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>

                     <div class="form-group row">
                        <label for="jenis_kelamin" class="col-sm-3 col-form-label text-right">Jenis Kelamin<code>*</code> : </label>
                        <div class="col-sm-6">
                           <div class="custom-control custom-radio custom-control-inline">
                              <input type="radio" id="customRadioInline1" name="jenis_kelamin" class="custom-control-input" <?php echo e($guru->jenis_kelamin==1?'checked':''); ?> value="1">
                              <label class="custom-control-label" for="customRadioInline1">Laki - Laki</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                              <input type="radio" id="customRadioInline2" name="jenis_kelamin" class="custom-control-input" value="0" <?php echo e($guru->jenis_kelamin==0?'checked':''); ?>>
                              <label class="custom-control-label" for="customRadioInline2">Perempuan</label>
                            </div>
                           <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('jenis_kelamin')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>

                     <div class="form-group row">
                        <label for="poto" class="col-sm-3 col-form-label text-right">Poto : </label>
                        <div class="col-sm-6">
                           <div class="custom-file">
                              <input type="file" class="custom-file-input" id="poto" name="poto" accept="image/*">
                              <label class="custom-file-label" for="poto">Choose file</label>
                            </div>
                           <?php $__errorArgs = ['poto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('poto')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>

                     <div class="form-group row">
                        <label for="alamat" class="col-sm-3 col-form-label text-right">Alamat<code>*</code> : </label>
                        <div class="col-sm-6">
                           <textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat" placeholder="Alamat Lengkap" name="alamat"><?php echo e($guru->alamat); ?></textarea>
                           <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($errors->first('alamat')); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>

                 </div>

                 <div class="card-footer text-center">
                     <button class="btn btn-primary mr-1" type="submit">Save</button>
                     <a href="<?php echo e(route('guru.index')); ?>" class="btn btn-secondary">Cancel</a>
                  </div>
               </form>

             </div>
         </div>
      </div>

   </div>
 </section>
   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script src="<?php echo e(asset('assets/datepicker/js/bootstrap-datepicker.js')); ?>"></script>

<script>
   $(document).ready(function(){
      $(".tanggal_lahir").datepicker({
         viewMode: 'years',
         format: 'yyyy/mm/dd'
      });

      $('.custom-file-input').on('change', function(){
         let filename = $(this).val().split('\\').pop();
         $(this).next('.custom-file-label').addClass("selected").html(filename);
      });
   });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\akademik\resources\views/guru/edit.blade.php ENDPATH**/ ?>