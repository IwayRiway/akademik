<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mapel;

class MapelController extends Controller
{
    public function __construct()
    {
        $this->middleware('roleaccess');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $judul = "Data Mata Pelajaran";
        $mapel = Mapel::all();

        return view('mapel.index', compact('judul', 'mapel'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $judul = "Data Mata Pelajaran";

        return view('mapel.create', compact('judul'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'nama' => ['required', 'unique:mapels,nama,NULL,id,deleted_at, NULL', 'max:20']
        ]);

        Mapel::create($request->all());
        return redirect()->route('mapel.index')->with('sukses', 'Data Berhasil Ditambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $judul = "Data Mata Pelajaran";
        $mapel = Mapel::findOrFail($id);

        return view('mapel.edit', compact('judul','mapel'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validate = $request->validate([
            'nama' => ['required', "unique:mapels,nama,$id,id", 'max:20']
        ]);

        Mapel::where('id',$id)->update($request->except('_token', '_method'));
        return redirect()->route('mapel.index')->with('info', 'Data Berhasil Diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Mapel::findOrFail($id)->delete();
        return redirect()->route('mapel.index')->with('warning', 'Data Berhasil Terhapus');
    }
}
